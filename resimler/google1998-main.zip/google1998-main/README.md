# CSS exam for www.patika.dev
## Google Google was like this for the first time
### https://web.archive.org/web/19981202230410if_/http://www.google.com/
