![My project-4](https://user-images.githubusercontent.com/89473605/174803138-6a4625d7-17ab-4b29-bbb4-ff4d2dcc5792.png)

# Google1998-css-task2
 Task from patika.dev about making clone of Google1998
![Ekran Resmi 2022-01-15 13 35 40](https://user-images.githubusercontent.com/89473605/149618701-536a8290-ac82-468f-a0a2-b1907310fcbb.png)
